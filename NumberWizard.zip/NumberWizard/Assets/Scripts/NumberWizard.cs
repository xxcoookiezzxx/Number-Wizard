﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NumberWizard : MonoBehaviour {
	
// Use this for initialization
	int max;
	int min;
	int guess;

	void Start () {
		StartGame ();
	
	}	

	void StartGame () {

		max = 1000;
		min = 1;
		guess = 500;

		max = max + 1;

		print ("===========================================================================");
		print ("Welcome My fellow cactus brothers and sisters, to the amazing NUMBER WIZARD");
		// print (" Welcome to NumberWizard" );
		print ("Think of a number in your head, but donʻt tell me!");

		print ("The highest number you can pick is 1000");
		print ("The lowest number you can pick is " + min);

		print ("Is the number higher or lower than " + guess);
		print ("Up arrow = higher, down = lower, return = equal");
	}
		
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.UpArrow)) {
			// print ("Up arrow pressed");
			min = guess;
			NextGuess ();
		} else if (Input.GetKeyDown (KeyCode.DownArrow)) {
			max = guess;
			NextGuess ();
			// print ("Down arrow pressed");
		} else if (Input.GetKeyDown (KeyCode.Return)) {
			print ("Good try young cactus, but I am triumphant!");
			// print ("I won");
			StartGame();
		}

	}

	void NextGuess () {
		guess = (max + min) / 2;
		print ("Higher or lower than " + guess);
		print ("Up arrow = higher, down = lower, return = equal");
	}
}

